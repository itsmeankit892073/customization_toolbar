package com.ankit.customtoolbar;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MenuInflater;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.ankit.customtoolbar.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar; // Correct import statement for Toolbar

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar); // Use setSupportActionBar instead of setActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("sub title");
        }
        toolbar.setTitle("my toolbar");
        toolbar.setSubtitle("sub title");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option, menu);
        return true; // Return true to indicate that the menu was inflated successfully
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

            if (item.getItemId() == R.id.opt_new) {
                Toast.makeText(this, "created a file", Toast.LENGTH_SHORT).show();
            } else if (item.getItemId() == R.id.opt_open) {
                Toast.makeText(this, "file opened", Toast.LENGTH_SHORT).show();
            } else if (item.getItemId() == R.id.opt_save) {
                Toast.makeText(this, "file saved successfully", Toast.LENGTH_SHORT).show();
            } else if (item.getItemId() == android.R.id.home) {
                onBackPressed();
            }
            return super.onOptionsItemSelected(item);
        }


}
